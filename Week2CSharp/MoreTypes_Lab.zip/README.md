<img src="https://boolerang.co.uk/wp-content/uploads/job-manager-uploads/company_logo/2018/04/SG-Logo-Black.png" alt="Sparta Logo" width="200"/>

---   
# Lab - More Data Types

## Setup
Download the starter code `MoreTypes_Lab_Starter` and open it in Visual Studio.

## Lab
1. Implement the methods in `MoreTypes_Lib.StringExercises` so that they pass all the tests in `MoreTypes_Tests.StringExercises_Tests` 

2. Implement the methods in `MoreTypes_Lib.ArrayExercises` so that they pass all the tests in `MoreTypes_Tests.ArrayExercises_Tests` 

3. Implement the methods in `MoreTypes_Lib.DateTimeEnumsExercises` so that they pass all the tests in `MoreTypes_Tests.DateTimeEnumsExercises_Tests` 