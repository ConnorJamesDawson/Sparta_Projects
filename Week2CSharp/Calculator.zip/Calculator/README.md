# My Calculator

## Functions

Along with the basic functions that a calculator has, this calculator can: 

- Read the users input on one line instead of waiting for 3 seperate inputs
- Read negative numbers correctly and functions work correctly with them (e.g 3--2 = 5)
